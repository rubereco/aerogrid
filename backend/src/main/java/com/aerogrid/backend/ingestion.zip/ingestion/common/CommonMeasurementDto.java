package com.aerogrid.backend.ingestion.common;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;

import java.time.LocalDateTime;

@Data
@Builder
public class CommonMeasurementDto {
    private String stationCode;
    private String pollutant;
    private Double value;
    private LocalDateTime timestamp;
}