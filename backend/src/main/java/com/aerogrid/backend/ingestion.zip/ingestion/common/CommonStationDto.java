package com.aerogrid.backend.ingestion.common;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CommonStationDto {
    private String code;
    private String name;
    private String municipality;
    private Double latitude;
    private Double longitude;
    private String type;
}