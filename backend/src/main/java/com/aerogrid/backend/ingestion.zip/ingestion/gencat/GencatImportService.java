package com.aerogrid.backend.ingestion.gencat;

import com.aerogrid.backend.domain.Measurement;
import com.aerogrid.backend.domain.Station;
import com.aerogrid.backend.ingestion.common.CommonMapper;
import com.aerogrid.backend.ingestion.common.CommonMeasurementDto;
import com.aerogrid.backend.ingestion.common.CommonStationDto;
import com.aerogrid.backend.ingestion.common.DataImportProvider;
import com.aerogrid.backend.repository.MeasurementRepository;
import com.aerogrid.backend.repository.StationRepository;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;
import java.util.List;

@Slf4j
@Service
public class GencatImportService implements DataImportProvider {

    private final GencatApiClient apiClient;
    private final GencatMapper mapper;
    private final CommonMapper commonMapper;
    private final StationRepository stationRepository;
    private final MeasurementRepository measurementRepository;

    public GencatImportService(GencatApiClient apiClient, GencatMapper mapper,
                               CommonMapper commonMapper,
                               StationRepository stationRepository,
                               MeasurementRepository measurementRepository) {
        this.apiClient = apiClient;
        this.mapper = mapper;
        this.commonMapper = commonMapper;
        this.stationRepository = stationRepository;
        this.measurementRepository = measurementRepository;
    }


    @Override
    public void importStations() {
        log.info("Iniciant importació d'estacions de {}", getProviderName());
        List<GencatRawDto> rawData = apiClient.getStations();

        for (GencatRawDto raw : rawData) {
            CommonStationDto station = mapper.toStationDto(raw);

            saveToDatabase(station);
        }
    }

    @Override
    public void importMeasurements() {

        List<GencatRawDto> rawData = apiClient.getMeasurements(LocalDate.now().toString());

        for (GencatRawDto raw : rawData) {

            List<CommonMeasurementDto> measurements = mapper.toMeasurementDtos(raw);

            for (CommonMeasurementDto dto : measurements) {
                saveToDatabase(dto);
            }
        }
    }

    private void saveToDatabase(CommonMeasurementDto dto) {
        Station station = stationRepository.findByCode(dto.getStationCode())
                .orElseThrow(() -> new RuntimeException("Station not found: " + dto.getStationCode()));

        Measurement measurement = commonMapper.toEntity(dto, station);

        measurementRepository.save(measurement);
    }

    private void saveToDatabase(CommonStationDto dto) {
        Station station = commonMapper.toEntity(dto);

        stationRepository.save(station);
    }

    @Override
    public String getProviderName() {
        return "Generalitat de Catalunya";
    }
}