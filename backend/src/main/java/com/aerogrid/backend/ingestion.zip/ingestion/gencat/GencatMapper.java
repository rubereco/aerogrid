package com.aerogrid.backend.ingestion.gencat;

import com.aerogrid.backend.domain.SourceType;
import com.aerogrid.backend.ingestion.common.CommonMeasurementDto;
import com.aerogrid.backend.ingestion.common.CommonStationDto;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Component
public class GencatMapper {

    // Mapper d'Estació: D'un Raw brut a un Station net
    public CommonStationDto toStationDto(GencatRawDto raw) {
        return CommonStationDto.builder()
                .code(raw.getStationCode())
                .name(raw.getStationName())
                .municipality(raw.getMunicipality())
                .latitude(parseDouble(raw.getLatitude()))
                .longitude(parseDouble(raw.getLongitude()))
                .type(SourceType.OFFICIAL.toString())
                .build();
    }

    // Mapper de Mesures: D'un Raw (horitzontal) a LLISTA de Mesures (vertical)
    public List<CommonMeasurementDto> toMeasurementDtos(GencatRawDto raw) {
        List<CommonMeasurementDto> measurements = new ArrayList<>();

        // La data base ve com "2026-01-29T00:00:00.000"
        LocalDateTime baseDate = LocalDateTime.parse(raw.getDate(), DateTimeFormatter.ISO_DATE_TIME);

        String stationCode = raw.getStationCode();
        String pollutant = raw.getPollutant();

        // Iterem sobre el mapa d'hores que hem capturat al RawDto
        raw.getHourlyValues().forEach((key, valueStr) -> {
            try {
                // key és "h01", "h02"... -> traiem la 'h' i tenim el número
                int hourIndex = Integer.parseInt(key.substring(1));

                // Convertim el valor (si és numèric)
                Double value = Double.valueOf(valueStr);

                // Calculem l'hora real (h01 sol ser la 1:00 AM, per tant sumem h-1 o h)
                // Generalment: Data base (00:00) + (hora - 1) hores.
                LocalDateTime realTimestamp = baseDate.plusHours(hourIndex - 1);

                measurements.add(CommonMeasurementDto.builder()
                        .stationCode(stationCode)
                        .pollutant(pollutant)
                        .value(value)
                        .timestamp(realTimestamp)
                        .build());

            } catch (NumberFormatException e) {
                // Ignorem valors que no siguin números o estiguin buits
                System.err.println("Error parsing value for hour " + key + ": " + valueStr + " - " + e.getMessage());
            }
        });

        return measurements;
    }

    private Double parseDouble(String value) {
        return (value != null) ? Double.valueOf(value) : null;
    }
}